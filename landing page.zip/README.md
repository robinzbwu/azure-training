# Landing create-react-app Example

详细使用请查看 landing 里的 [use in create-react-app](https://landing.ant.design/docs/use/create-react-app)

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

